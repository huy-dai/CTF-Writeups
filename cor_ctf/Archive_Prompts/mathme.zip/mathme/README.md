# mathme

**Difficulty:** Medium or Hard

**Description:** `i need math help, so i made a website where people can send me math notes.`

