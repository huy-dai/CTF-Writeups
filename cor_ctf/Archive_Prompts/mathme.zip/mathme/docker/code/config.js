module.exports = {
	secret: Buffer.from('dcff3f05f289a18d6598886b28cbd9947b806cd5021d07a557d4237551381b96', 'hex')
}