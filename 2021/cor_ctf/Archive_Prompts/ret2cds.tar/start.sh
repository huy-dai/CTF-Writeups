#!/bin/sh
cd /home/ret2cds
while true; do java -jar /opt/nc-java/nc-java.jar ./ret2cds 1337; done